package Lista;
public class No {
    public int info;
    public No proximo;
    
    public void showNo(){
        System.out.println("Info: "+info+ "   Próximo->"+proximo);
    }
}
