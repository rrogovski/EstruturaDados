
package listas;

import Lista.Lista;

public class Listas {
    
    public static void main(String[] args) {
        Lista l = new Lista();
        l.addFirst(10);
        l.addLast(20);
        l.addFirst(30);
        l.addLast(50);
        l.addLastValue(20, 45);
        l.addLastValue(10, 15);
        l.addLastValue(18, 90);
        l.removeInfo(20);
        l.showList();
    }    
}
